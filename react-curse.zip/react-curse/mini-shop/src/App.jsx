
import './App.css'
import Product from './components/Product'

const products = [
  {
    id: 1,
    name: "iPhone 15",
    price: 800,
    category: "Phone"
  },
  {
    id: 2,
    name: "Samsung S24",
    price: 700,
    category: "Phone"
  },
    {
    id: 3,
    name: "Huawey 10s ultra",
    price: 300,
    category: "Phone"
  },
    {
    id: 4,
    name: "MacBook",
    price: 1700,
    category: "nootbook"
  },
    {
    id: 5,
    name: "HP",
    price: 1200,
    category: "nootbook"
  }
];

function App  (){
  return(
    <div>
   <h1>Mini Shop</h1>
    {products.map((item)=>(
      <Product 
      id ={item.id}
      name ={item.name}
      price ={item.price}
      category ={item.category}
      />
    ))}
  </div>
  )
}

export default App
