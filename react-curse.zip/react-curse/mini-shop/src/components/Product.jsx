

function Product(props) {
  return (
    <div>
      <h2>{props.name}</h2>
      <p>{props.id}</p>
      <p>{props.price}</p>
      <p>{props.category}</p>
    </div>
  );
}
export default Product